from setuptools import setup

setup(
    name='taskmanager',
    version='1.0',
    scripts=['taskmanager.py'],
)
