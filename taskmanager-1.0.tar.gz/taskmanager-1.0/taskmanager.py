import platform
import psutil
import GPUtil
import cpuinfo
import socket
import tkinter as tk
from tkinter import ttk, messagebox

class TaskManagerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Task Manager")
        
        self.tabs = ttk.Notebook(root)
        
        # Processes tab
        self.processes_frame = ttk.Frame(self.tabs)
        self.processes_frame.grid_rowconfigure(0, weight=1)
        self.processes_frame.grid_columnconfigure(0, weight=1)
        
        self.tree = ttk.Treeview(self.processes_frame, columns=("pid", "name", "cpu", "memory"), show="headings")
        self.tree.heading("pid", text="PID")
        self.tree.heading("name", text="Name")
        self.tree.heading("cpu", text="CPU %")
        self.tree.heading("memory", text="Memory Usage")
        self.tree.grid(row=0, column=0, sticky="nsew")
        
        self.refresh_button = ttk.Button(self.processes_frame, text="Refresh", command=self.refresh_processes)
        self.refresh_button.grid(row=1, column=0, padx=5, pady=5, sticky="e")
        
        self.kill_button = ttk.Button(self.processes_frame, text="Kill Process", command=self.kill_process)
        self.kill_button.grid(row=1, column=0, padx=5, pady=5, sticky="w")
        
        self.tabs.add(self.processes_frame, text="Processes")
        
        # Performance tab
        self.performance_frame = ttk.Frame(self.tabs)
        self.performance_frame.grid_rowconfigure(0, weight=1)
        self.performance_frame.grid_columnconfigure(0, weight=1)
        
        # Display System Information
        system_info = self.get_system_info()
        system_info_label = ttk.Label(self.performance_frame, text=system_info, wraplength=600, justify='left')
        system_info_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")

        # Display GPU Information
        gpu_info = self.get_gpu_info()
        gpu_info_label = ttk.Label(self.performance_frame, text=gpu_info, wraplength=600, justify='left')
        gpu_info_label.grid(row=1, column=0, padx=10, pady=10, sticky="w")

        # Display Network Information
        network_info = self.get_network_info()
        network_info_label = ttk.Label(self.performance_frame, text=network_info, wraplength=600, justify='left')
        network_info_label.grid(row=2, column=0, padx=10, pady=10, sticky="w")

        self.tabs.add(self.performance_frame, text="Performance")
        
        self.tabs.pack(fill="both", expand=True)
        
        self.refresh_processes()
        self.update_performance()

    def refresh_processes(self):
        self.tree.delete(*self.tree.get_children())
        for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
            try:
                pid = proc.info['pid']
                name = proc.info['name']
                cpu = proc.info['cpu_percent']
                memory = proc.info['memory_percent']
                self.tree.insert("", "end", values=(pid, name, cpu, memory))
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                pass
    
    def kill_process(self):
        selected_item = self.tree.selection()
        if len(selected_item) == 0:
            messagebox.showinfo("Error", "No process selected.")
            return
        
        pid = int(self.tree.item(selected_item, "values")[0])
        try:
            process = psutil.Process(pid)
            process.terminate()
            self.refresh_processes()
            messagebox.showinfo("Success", f"Process with PID {pid} terminated successfully.")
        except psutil.NoSuchProcess:
            messagebox.showinfo("Error", f"Process with PID {pid} no longer exists.")
        except psutil.AccessDenied:
            messagebox.showinfo("Error", f"Permission denied to terminate process with PID {pid}.")
    
    def get_system_info(self):
        system_info = "System Information:\n\n"
        system_info += f"System: {platform.system()} {platform.release()} {platform.version()}\n"
        system_info += f"Processor: {platform.processor()} ({self.get_cpu_info()})\n"
        system_info += f"CPU Count: {psutil.cpu_count(logical=False)} (Physical)\n"
        system_info += f"CPU Cores: {psutil.cpu_count(logical=True)} (Logical)\n"
        system_info += f"RAM: {psutil.virtual_memory().total / (1024 ** 3):.2f} GB\n"
        
        return system_info
    
    def get_cpu_info(self):
        info = cpuinfo.get_cpu_info()
        return info['brand_raw']

    def get_gpu_info(self):
        gpus = GPUtil.getGPUs()
        gpu_info = "GPU Information:\n\n"
        for i, gpu in enumerate(gpus):
            gpu_info += f"GPU {i+1}: {gpu.name} | Utilization: {gpu.load*100:.2f}% | Memory Usage: {gpu.memoryUtil*100:.2f}%\n"
        return gpu_info
    
    def get_network_info(self):
        network_info = "Network Information:\n\n"
        for interface, addrs in psutil.net_if_addrs().items():
            network_info += f"Interface: {interface}\n"
            for addr in addrs:
                if addr.family == socket.AF_INET:
                    network_info += f"  IP Address: {addr.address}\n"
                elif addr.family == socket.AF_INET6:
                    network_info += f"  IPv6 Address: {addr.address}\n"
        return network_info

    def update_performance(self):
        pass

root = tk.Tk()
app = TaskManagerApp(root)
root.mainloop()
